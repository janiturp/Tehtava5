#include "Pelihahmo.h"

void Pelihahmo::SetSijainti(Maastoruutu* sijainti)
{
	_sijainti = sijainti;
}
