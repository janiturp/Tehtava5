#pragma once
#include <string>
using namespace std;

class Objekti
{
public:
	string _nimi;

	Objekti(string nimi)
	{
		_nimi = nimi;
	}
};

