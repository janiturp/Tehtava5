#include "MuuObjekti.h"

void MuuObjekti::SetSijainti(Maastoruutu* sijainti)
{
	_sijainti = sijainti;
}