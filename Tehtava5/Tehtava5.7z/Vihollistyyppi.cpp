#include "Vihollistyyppi.h"


int Vihollistyyppi::GetAlkuHP()
{
	return _alku_hp;
}

int Vihollistyyppi::GetAlkuHyokkaysvoima()
{
	return _alku_hyokkaysvoima;
}

int Vihollistyyppi::GetAlkuPuolustusvoima()
{
	return _alku_puolustusvoima;
}