#include "Taisteluvaruste.h"

void Taisteluvaruste::SetSijainti(Maastoruutu* sijainti)
{
	_sijainti = sijainti;
}