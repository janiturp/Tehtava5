#include "Maastoruutu.h"

void Maastoruutu::SetMaastotyyppi(Maastotyyppi tyyppi)
{
	_tyyppi = tyyppi;
}

int Maastoruutu::GetX()
{
	return _x;
}

int Maastoruutu::GetY()
{
	return _y;
}
