#pragma once
class Karttapohja
{
public:
	Karttapohja() {};
};

